
/**this Node class is used for decision tree only*/
public class Node {
	String Data; // represents name
	Node left;    // left child (left subtree)
	Node right;   // right child (right subtree)	
	boolean leaf; // is leaf node
	
	public Node(String Data, boolean l) {//create constructor for Node
		this.Data = Data;
		this.left=this.right=null;
		this.leaf = l;//whether the node is leaf or not
	}
	
	public Node() {//default node
		this.left = null;
		this.right=null;
		this.leaf = false;
	}
	
	boolean isLeaf() {	//evaluate whether the node is leaf or not
		return this.leaf;
	}
	
	public static Node createNode(String choice, boolean leaf) {//create a createNode method in order to add nodes by level in mainmethod
		return new Node(choice, leaf);
	}
	
	public static Node createNode(String choice) {//create a createNode method in order to add nodes by level in mainmethod
		return new Node(choice, false);
	}
}


