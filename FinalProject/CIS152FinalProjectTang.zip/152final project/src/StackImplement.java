
import java.util.Stack;
import java.util.Iterator;
/**The purpose of establishing stack*/
public class StackImplement {
	Stack<String> workItems;
	
	public StackImplement() {
		workItems = new Stack<>();//see workItems class

		// Add elements to stack. All the elements are the lowest levels of the
		// different categories of work(e.g., either in level 4 or level 5)
		workItems.push("USDA");
		workItems.push("NIH");
		workItems.push("Google");
		workItems.push("IBM");
		workItems.push("E-WOM");
		workItems.push("E-Booking");
		workItems.push("Ads");
		workItems.push("PR");
		workItems.push("ML");
		workItems.push("Eye-tracking");
		workItems.push("Pricing");
		workItems.push("Branding");
		workItems.push("MGMT113");
		workItems.push("HSPM297");
		workItems.push("MGMT613");
		workItems.push("MGMT513");
		workItems.push("MGMT213");
		workItems.push("HSPM397");
		workItems.push("MGMT623");
		workItems.push("MGMT523");
	}
	
	public void insert(String title) {//insert the title of the added element
		workItems.push(title);
	}
	
	public void delete(String title) {//delete the title of the element
		workItems.remove(title);
	}
	
	@Override
	public String toString() {//print out the stack elements
		String res="<html>";
		Iterator<String> value = workItems.iterator();
		while (value.hasNext()) {//print out in multiple rows
            res += "title=" + value.next() + "<br>";
        }
		res += "</html>";
		
		return res;
	}
}
