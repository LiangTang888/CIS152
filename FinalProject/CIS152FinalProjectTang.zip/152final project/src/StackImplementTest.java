import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;


class StackImplementTest {//Junit test for stack 

	@Test
	void test() {
		StackImplement s =  new StackImplement();
		assertEquals(true, s.workItems.contains("USDA")); //test whether the stack contains "USDA"
		assertEquals(false, s.workItems.contains("FOO"));//test whether the stack contains "FOO"
		s.insert("FOO"); //add "FOO" into the stack
		assertEquals(true, s.workItems.contains("FOO"));//test whether the new stack contains "FOO"
		s.delete("FOO"); //delete "FOO" in the stack 
		assertEquals(false, s.workItems.contains("FOO"));//test whether the new stack contains "FOO"
	}

}
