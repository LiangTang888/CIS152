

public enum Decision {//three choice for the user, yes, no, or exit from the page
	YES, NO, EXIT
}
