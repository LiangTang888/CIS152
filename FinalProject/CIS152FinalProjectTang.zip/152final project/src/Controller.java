
/**The class of controller is part of model-view-controller architectural pattern used for GUI. */
public class Controller {
	public Model model;//model, view, controller are related, so declarations of mode and view are needed in the class of controller
	public View view;
	
	public Controller (Model m, View v) {//constructor of controller
		model = m;
		view = v;
	}
	
	public void init() {//when the ok button is clicked, the view of the frame needs to be updated accordingly
		view.frame.okButton.addActionListener(e -> updateModelView());
	}
	
	public void updateModelView() {//method of how to update the view of presenting data to user
		WorkMethod method = WorkMethod.DECISION_TREE; //this method is for decision tree
		if (view.frame.greetingPanel.isVisible()) {//greetingPanel is defined in ProfessorAssistFrame class
			if (view.frame.decisionTreeRadioButton.isSelected()) {//if user  clicks the choice of decision tree radio button
				method = WorkMethod.DECISION_TREE; //implement decision tree method
			} else if (view.frame.priorityQueueRadioButton.isSelected()) { //if user clicks the choice of priority queue radio button
				method = WorkMethod.PRIORITY_QUEUE; //implement priority queue method
			} else if(view.frame.stackRadioButton.isSelected()) {//if user clicks the choice of stack
				method = WorkMethod.STACK;//implement stack method
			}
		} else if ( view.frame.decisionPanel.isVisible()) {//decisionPanel is defined in ProfessorAssistFrame class
			method = WorkMethod.DECISION_TREE;
		} else if (view.frame.assignmentRequestPanel.isVisible()) {//assignmentRequestPanel is defined in ProfessorAssistFrame class
			method = model.method;
		}
		
		Input input = new Input();
		if (method == WorkMethod.DECISION_TREE) {//if the choice of decision tree is selected
			if(view.frame.decisionPanel.isVisible()) {
				if (view.frame.yesRadioButton.isVisible() && view.frame.yesRadioButton.isSelected()) {
					input.decision = Decision.YES; //refers to yes, go to decision tree
				} else if (view.frame.noRadioButton.isVisible() && view.frame.noRadioButton.isSelected()) {
					input.decision = Decision.NO; //refers to no, not to choose decision tree
				} else {
					input.decision = Decision.EXIT; //exit from the decision
				}
			}
		} else if (method == WorkMethod.PRIORITY_QUEUE || method == WorkMethod.STACK) {
			if (view.frame.assignmentRequestPanel.isVisible()) {
				if (view.frame.assignmentDisplayRadioButton.isVisible() && view.frame.assignmentDisplayRadioButton.isSelected()) {
					input.action = Action.DISPLAY;
				} else if (view.frame.assignmentAddRadioButton.isVisible() && view.frame.assignmentAddRadioButton.isSelected()) {
					input.action = Action.ADD;
					input.title = view.frame.assignmentAddTitleTextField.getText();
					input.priority = Integer.parseInt(view.frame.assignmentAddPriorityTextField.getText());
				} else if (view.frame.assignmentRemoveRadioButton.isVisible() && view.frame.assignmentRemoveRadioButton.isSelected()) {
					input.action = Action.REMOVE;
					input.title = view.frame.assignmentRemoveTitleTextField.getText();
				}
			}
		}
		model.update(method, input); //update the model with new info of method and input
		
		view.update(input, model); //view also needs to be updated accordingly. Again, model, view, and controllers should be updated together
	}
}
