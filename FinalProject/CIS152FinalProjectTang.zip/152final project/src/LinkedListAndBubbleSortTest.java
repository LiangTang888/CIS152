import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

/**Junit test for linkedlistAndBubbleSort class*/
class LinkedListAndBubbleSortTest {
	final String expected = "<html>title=IBM grant, priority=20<br>title=Ads journal paper, priority=19<br>title=E-Booking journal paper, priority=18<br>title=USDA grant, priority=17<br>title=ML conference proceeding, priority=16<br>title=Google grant, priority=15<br>title=NIH grant, priority=14<br>title=Grading MGMT113, priority=13<br>title=E-WOM journal paper, priority=12<br>title=Branding conference proceeding, priority=11<br>title=Grading HSPM297, priority=10<br>title=Eye-tracking conference proceeding, priority=9<br>title=PR journal paper, priority=8<br>title=Pricing conference proceeding, priority=7<br>title=Preparing HSPM397, priority=6<br>title=Grading MGMT513, priority=5<br>title=Preparing MGMT523, priority=4<br>title=Grading MGMT613, priority=3<br>title=Preparing MGMT623, priority=2<br>title=Preparing MGMT213, priority=1<br></html>";
	final String expectedAddFoo = "<html>title=IBM grant, priority=20<br>title=Ads journal paper, priority=19<br>title=E-Booking journal paper, priority=18<br>title=USDA grant, priority=17<br>title=ML conference proceeding, priority=16<br>title=Google grant, priority=15<br>title=NIH grant, priority=14<br>title=Grading MGMT113, priority=13<br>title=E-WOM journal paper, priority=12<br>title=Branding conference proceeding, priority=11<br>title=FOO, priority=10<br>title=Grading HSPM297, priority=10<br>title=Eye-tracking conference proceeding, priority=9<br>title=PR journal paper, priority=8<br>title=Pricing conference proceeding, priority=7<br>title=Preparing HSPM397, priority=6<br>title=Grading MGMT513, priority=5<br>title=Preparing MGMT523, priority=4<br>title=Grading MGMT613, priority=3<br>title=Preparing MGMT623, priority=2<br>title=Preparing MGMT213, priority=1<br></html>";
	
	@Test
	void test() {
		LinkedListAndBubbleSort l =  new LinkedListAndBubbleSort();//create an object
		assertEquals(expected, l.toString());//print out the linkedlist without sorting
		l.insert("FOO", 10); //insert "FOO"
		l.bubbleSort();//bubble sort the linkedlist after adding "FOO"
		assertEquals(expectedAddFoo, l.toString()); //print out linkedlist after adding and sorting
		l.delete("FOO");//delete "FOO"
		assertEquals(expected, l.toString());//print out linkedlist after deleting "FOO"
	}

}
