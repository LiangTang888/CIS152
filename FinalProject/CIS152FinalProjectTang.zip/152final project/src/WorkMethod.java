

public enum WorkMethod {//there are three work methods used in GUI
	DECISION_TREE, PRIORITY_QUEUE, STACK
}
