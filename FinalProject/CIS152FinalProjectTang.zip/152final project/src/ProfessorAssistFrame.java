import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.ButtonGroup;
import javax.swing.BoxLayout;
import javax.swing.JTextField;
/**************************************************************
* Name        : SuperClass
* Author      : Liang Tang
* Created     : 3/2/2022
* Course      : CIS 152 Data Structures
* Version     : 1.0
* OS          : Windows 10
* Copyright   : This is my own original work based on
*               specifications issued by our instructor
* Description : This program overall description here 
*               Input: GUI input and interaction with users. Users to choose one of the three options (decision tree, priority queue, and stack)
*   			
*               Output: for decision tree, direct user until a leaf. For priority queue/stack, users could add/delete and show the list of elements sorted
* Academic Honesty: I attest that this is my original work.
* I have not used unauthorized source code, either modified or 
* unmodified. I have not given other fellow student(s) access to
* my program.         
***************************************************************/
public class ProfessorAssistFrame extends JFrame {
	final int FRAME_WIDTH = 800; //frame refers to the message box in GUI, width of the frame
	final int FRAME_HEIGHT = 600; //height of frame
	final String TITLE = "Professor Assist";//title on the top of the message box
	final String greeting = "<html>Good morning, Dr. Shoemaker!<br>How do you want me to help you choose the work today? (Please only choose one)</html>";//print the two sentences in two rows 
	final String finalChoice = "Your choice for today's work is "; //the initial message 
	final String assignmentRequest = "What do you want to do with assignment?"; //question used in stack/priority queue
	final String assignmentResult = "The work assignments in order are:"; //the sorted queue by priority/stack(from most updated to most outdated)
	final int TEXT_FIELD_SIZE = 30;//the hard coding
	
	public JPanel mainPanel; //main panel
	
	public JPanel greetingPanel; //refers to the panel for the initial message
	public JLabel greetingLabel; //refers to the label for the initial message
	public JButton okButton; //after making choices, user needs to click ok button
	public JRadioButton decisionTreeRadioButton; //button for decision tree
	public JRadioButton priorityQueueRadioButton; //button for priority queue
	public JRadioButton stackRadioButton; //button for stack
	public ButtonGroup greetingButtonGroup; //group greeting buttons together
	
	public JPanel decisionPanel; //panel for choices
	public JLabel decisionLabel; //label for choices
	public JRadioButton yesRadioButton; //the button of yes
	public JRadioButton noRadioButton; //the button of no
	public ButtonGroup decisionButtonGroup; //group the buttons of choices
	
	public JPanel assignmentRequestPanel; //panel which demonstrates the request(user input what he/she wants to do)
	public JLabel assignmentRequestLabel;
	public JRadioButton assignmentDisplayRadioButton;//display stack/priority queue
	public JRadioButton assignmentAddRadioButton;  //add an element to stack/priority queue
	public JLabel assignmentAddTitleLabel; //the message that asks users to add title of element into priority queue/stack
	public JTextField assignmentAddTitleTextField;
	public JLabel assignmentAddPriorityLabel; //the message that asks users to add priority of element into priority queue/stack
	public JTextField assignmentAddPriorityTextField;
	public JRadioButton assignmentRemoveRadioButton; //delete an element from stack/priority queue
	public JLabel assignmentRemoveTitleLabel;
	public JTextField assignmentRemoveTitleTextField;	
	public ButtonGroup assignmentButtonGroup; //group assignment buttons together

	public JPanel assignmentResultPanel;// after taking some actions (i.e., add/delete), demonstrate the result
	public JLabel assignmentResultLabel;
	public JLabel assignmentResultOutputLabel;
	public JLabel assignmentResultOutputTestLabel;

	public ProfessorAssistFrame() {//method of create a frame
		createComponents(); //add info into the frame
		setSize(FRAME_WIDTH, FRAME_HEIGHT);//set size of message box
		setTitle(TITLE); //add a title to the frame
	}
	
	private void createComponents() {
		// greeting panel, which is the initial message when the users open the app
		greetingLabel = new JLabel(greeting);
		decisionTreeRadioButton = new JRadioButton("Decision Tree"); //initial status is to select
		decisionTreeRadioButton.setSelected(true);
		priorityQueueRadioButton = new JRadioButton("Priority Queue");//initial status is not to select
		priorityQueueRadioButton.setSelected(false);
		stackRadioButton = new JRadioButton("Stack"); //initial status is not to select
		stackRadioButton.setSelected(false);
		greetingButtonGroup = new ButtonGroup();//create a button group and add decision tree radio button, priority queue botton, and stack button into the group
		greetingButtonGroup.add(decisionTreeRadioButton);
		greetingButtonGroup.add(priorityQueueRadioButton);
		greetingButtonGroup.add(stackRadioButton);
		
		greetingPanel = new JPanel(); //create a new JPanel
		greetingPanel.setLayout(new BoxLayout(greetingPanel, BoxLayout.Y_AXIS)); //demonstrate the choices in multiple rows
		greetingPanel.add(greetingLabel);//add the greeting message in the initial message
		greetingPanel.add(decisionTreeRadioButton);//ask the users to select one of the three radio buttons
		greetingPanel.add(priorityQueueRadioButton);
		greetingPanel.add(stackRadioButton);
		greetingPanel.setVisible(true);//at initial stage, make the messages and radio buttons aforementioned visible
		
		// decision panel
		decisionLabel = new JLabel("Choose your decision"); //question
		yesRadioButton = new JRadioButton("Yes"); //choose yes or no radio button
		yesRadioButton.setSelected(true);
		noRadioButton = new JRadioButton("No");
		noRadioButton.setSelected(false);
		decisionButtonGroup = new ButtonGroup();//create a button group, and add yes and no into the button group
		decisionButtonGroup.add(yesRadioButton);
		decisionButtonGroup.add(noRadioButton);
		
		decisionPanel = new JPanel();
		decisionPanel.setLayout(new BoxLayout(decisionPanel, BoxLayout.Y_AXIS));//print in multiple rows
		decisionPanel.add(decisionLabel);
		decisionPanel.add(yesRadioButton);
		decisionPanel.add(noRadioButton);
		decisionPanel.setVisible(false);//when the greeting message is available, the decision tree and yes/no choices are invisible
		
		// assignment request panel, the request such as to prompt users to input title and priority of elements added or title of element deleted
		assignmentRequestLabel = new JLabel(assignmentRequest);
		assignmentDisplayRadioButton = new JRadioButton("Display the work assigments");
		assignmentDisplayRadioButton.setSelected(true);//select display radio button "display the work assignment"
		assignmentAddRadioButton = new JRadioButton("Add the work assigment");
		assignmentAddRadioButton.setSelected(true);//select "add the work assignment"
		assignmentAddTitleLabel = new JLabel("Title");// prompt the user to input "title" of added element
		assignmentAddTitleTextField = new JTextField(TEXT_FIELD_SIZE);
		assignmentAddTitleTextField.setMaximumSize(assignmentAddTitleTextField.getPreferredSize());
		assignmentAddPriorityLabel = new JLabel("Priority");//prompt the user to input "priority" of added element
		assignmentAddPriorityTextField = new JTextField(TEXT_FIELD_SIZE);
		assignmentAddPriorityTextField.setMaximumSize(assignmentAddPriorityTextField.getPreferredSize());
		assignmentRemoveRadioButton = new JRadioButton("Remove the work assigment");//create a radio button of "remove the work assignment"
		assignmentRemoveRadioButton.setSelected(true); //select the option of radio button for removing the work assignment
		assignmentRemoveTitleLabel = new JLabel("Title");
		assignmentRemoveTitleTextField = new JTextField(TEXT_FIELD_SIZE);
		assignmentRemoveTitleTextField.setMaximumSize(assignmentRemoveTitleTextField.getPreferredSize());
		assignmentButtonGroup = new ButtonGroup();//put the following radio buttons into the group
		assignmentButtonGroup.add(assignmentDisplayRadioButton);
		assignmentButtonGroup.add(assignmentAddRadioButton);
		assignmentButtonGroup.add(assignmentRemoveRadioButton);
		
		assignmentRequestPanel = new JPanel();
		assignmentRequestPanel.setLayout(new BoxLayout(assignmentRequestPanel, BoxLayout.Y_AXIS));
		assignmentRequestPanel.add(assignmentRequestLabel);//add the display, add, remove title and priority messages into the assignment request panel
		assignmentRequestPanel.add(assignmentDisplayRadioButton);
		assignmentRequestPanel.add(assignmentAddRadioButton);
		assignmentRequestPanel.add(assignmentAddTitleLabel);
		assignmentRequestPanel.add(assignmentAddTitleTextField);
		assignmentRequestPanel.add(assignmentAddPriorityLabel);
		assignmentRequestPanel.add(assignmentAddPriorityTextField);
		assignmentRequestPanel.add(assignmentRemoveRadioButton);
		assignmentRequestPanel.add(assignmentRemoveTitleLabel);
		assignmentRequestPanel.add(assignmentRemoveTitleTextField);
		assignmentRequestPanel.setVisible(false);//initially, the assignment request panel is invisible

		// assignment result panel
		assignmentResultLabel = new JLabel(assignmentResult);//after the program receives the assignment request, implement the corresponding program, and then demonstrate the result
		assignmentResultOutputLabel = new JLabel();
		assignmentResultOutputTestLabel = new JLabel();
		
		assignmentResultPanel = new JPanel();
		assignmentResultPanel.setLayout(new BoxLayout(assignmentResultPanel, BoxLayout.Y_AXIS));
		assignmentResultPanel.add(assignmentResultLabel);//add these three things into assignment result panel
		assignmentResultPanel.add(assignmentResultOutputLabel);
		assignmentResultPanel.add(assignmentResultOutputTestLabel);
		assignmentResultPanel.setVisible(false); //initially, the assignment result panel is invisible

		// main panel
		okButton = new JButton("OK");
		
		mainPanel = new JPanel();
		mainPanel.setLayout(new BoxLayout(mainPanel, BoxLayout.Y_AXIS));
		mainPanel.add(greetingPanel);//mainPanel includes four panels, switch one by one
		mainPanel.add(decisionPanel);
		mainPanel.add(assignmentRequestPanel);
		mainPanel.add(assignmentResultPanel);
		mainPanel.add(okButton);//ok button on the main panel
		add(mainPanel);
	}
	
	public void update(Input input, Model model) {
		if (model.method == WorkMethod.DECISION_TREE) {//if choose the method of decision tree
			if (greetingPanel.isVisible()) {
				greetingPanel.setVisible(false);//when making choice, the greenpanel turns invisible, and then make decision panel visible
				decisionPanel.setVisible(true);
			}
			
			if (model.currDecisionTreeNode.isLeaf()) {//check whether the current node moves to the end of the decision tree or not
				decisionLabel.setText(finalChoice + model.currDecisionTreeNode.Data);
				yesRadioButton.setVisible(false);//don't show yes, no, ok buttons
				noRadioButton.setVisible(false);
				okButton.setVisible(false);
			} else {
				decisionLabel.setText(model.currDecisionTreeNode.Data);//show the leaf of the decision tree
			}
			
		} else if (model.method == WorkMethod.PRIORITY_QUEUE || model.method == WorkMethod.STACK) {//if choose priority queue or stack
			if (greetingPanel.isVisible()) {
				greetingPanel.setVisible(false);
				assignmentRequestPanel.setVisible(true);//make the assignment request panel visible
			} else if (assignmentRequestPanel.isVisible()) {
				assignmentRequestPanel.setVisible(false);
				assignmentResultPanel.setVisible(true);//make assignment result panel visible
				if (model.method == WorkMethod.PRIORITY_QUEUE) {
					assignmentResultOutputLabel.setText(model.priorityQueue.toString());
					// Test priority queue and stack are in-sync(opt it out, since it is just for testing purpose)
					// assignmentResultOutputTestLabel.setText(model.stack.toString());
				} else {
					assignmentResultOutputLabel.setText(model.stack.toString());
					// Test priority queue and stack are in-sync (opt it out, since it is just for testing purpose)
					// assignmentResultOutputTestLabel.setText(model.priorityQueue.toString());
				}
				
				okButton.setVisible(false);
			}
		}
	}
}
