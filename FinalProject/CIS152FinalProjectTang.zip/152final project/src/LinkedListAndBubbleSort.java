import java.util.LinkedList;

class LinkedListNode {
	String title; // name of each work item
	int priority; // each work item at the bottom level is assigned a priority
	LinkedListNode next; // node pointer

	public  LinkedListNode(String title, int priority) {// constructor of Node
		this.title = title;
		this.priority = priority;
		this.next = null;
	}
}

public class LinkedListAndBubbleSort {
	private LinkedListNode head; // declaration of head node

	LinkedListAndBubbleSort() {// default constructor
		this.head = null;
		
		init();
	}
	
	void init() {
		/**
		 * use insert method to add the individual work items which are leaf of the
		 * tree(see decision tree
		 */
		insert("USDA grant", 17);
		insert("NIH grant", 14);
		insert("Google grant", 15);
		insert("IBM grant", 20);
		insert("E-WOM journal paper", 12);
		insert("E-Booking journal paper", 18);
		insert("Ads journal paper", 19);
		insert("PR journal paper", 8);
		insert("ML conference proceeding", 16);
		insert("Eye-tracking conference proceeding", 9);
		insert("Pricing conference proceeding", 7);
		insert("Branding conference proceeding", 11);
		insert("Grading MGMT113", 13);
		insert("Grading HSPM297", 10);
		insert("Grading MGMT613", 3);
		insert("Grading MGMT513", 5);
		insert("Preparing MGMT213", 1);
		insert("Preparing HSPM397", 6);
		insert("Preparing MGMT623", 2);
		insert("Preparing MGMT523", 4);
		
		bubbleSort();
	}

	/** insert the new node at the start of the linkedlist */
	public void insert(String title, int priority) {
		LinkedListNode node = new LinkedListNode(title, priority);// create a node
		node.next = this.head; // add the node at the front of the linkedlist
		this.head = node; // the new node becomes the new head
	}
	
	public void delete(String title) {
		if (this.head == null) return;
		LinkedListNode prev=null, curr=head;  //current node is head
		while (curr != null) {//the linkedlist is not null
			if (curr.title.equals(title)) {
				if (prev == null) {
					head = curr.next;
				} else {
					prev.next = curr.next;
				}
				break;
			}
			prev=curr;//after deletion, move forward
			curr = curr.next;
		}
	}

	/** demonstrate all the elements in the linkedlist */
	@Override
	public String toString() {
		String res="<html>";
		if (this.head != null) {
			LinkedListNode temp = this.head; // print from the head of the linkedlist
			while (temp != null) {
				res += "title=" + temp.title + ", priority=" + temp.priority + "<br>";
				temp = temp.next;// move to next node
			}
		} else {//if temp ==null
			res = "You work list is empty! You don't need to work today!";
		}
		res += "</html>";
		return res;
	}

	/** bubble sort method */
	public void bubbleSort() {
		if (head != null) {
			LinkedListNode present = null;
			boolean isDone = false;// check the status of sorting
			do {
				present = this.head; // start sorting from the first node
				isDone = false;// for each loop, need to reset the status
				while (present != null && present.next != null) {// means at least two nodes in the list, otherwise,
																	// can't swap
					if (present.priority < present.next.priority) {// higher priority should be listed before the one
																	// with lower priority
						/** swap the priority and title of two nodes */
						String tempTitle = present.title;
						int tempPriority = present.priority;
						present.title = present.next.title;
						present.priority = present.next.priority;
						present.next.title = tempTitle;
						present.next.priority = tempPriority;
						isDone = true;// after swap the priority and title of two nodes, change the status
					}
					present = present.next;// move to next node
				}
			} while (isDone);
		} else {
			System.out.println("Your work list is empty! You don't need to work today!");
		}
	}
}
