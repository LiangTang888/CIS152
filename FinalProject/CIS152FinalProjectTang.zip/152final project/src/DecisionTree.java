import java.util.Scanner;

public class DecisionTree {

	public Node root;
	public DecisionTree() {

		/* input nodes by level */
		// root level0
		Node A = Node.createNode("Want to focus on research today?");
		root = A;
		// level1
		Node B = Node.createNode("Want to focus on grants?");
		Node C = Node.createNode("Want to do grading?");
		// level2
		Node B1 = Node.createNode("Grants on federal sponsors?");
		Node B2 = Node.createNode("Want to write journal papers?");
		Node C1 = Node.createNode("Grading for undergraduate courses?");
		Node C2 = Node.createNode("Class preparation for undergraduate courses?");

		// level3
		Node B1a = Node.createNode("Agriculture related?");
		Node B1b = Node.createNode("Company?");
		Node B2a = Node.createNode("Journal papers on digital marketing?");
		Node B2b = Node.createNode("Conference proceedings on IT in marketing?");
		Node C1a = Node.createNode("Grading marketing courses?");
		Node C1b = Node.createNode("Grading courses for Ph.D.?");
		Node C2a = Node.createNode("Teaching marketing courses?");
		Node C2b = Node.createNode("Teaching courses for Ph.D.?");

		// level4
		Node B1aA = Node.createNode("USDA", true);
		Node B1aB = Node.createNode("NIH", true);
		Node B1bA = Node.createNode("Google", true);
		Node B1bB = Node.createNode("IBM", true);
		Node B2aA = Node.createNode("Journal papers on review websites?");
		Node B2aB = Node.createNode("Journal papers on promotion?");
		Node B2bA = Node.createNode("Big data?");
		Node B2bB = Node.createNode("Budget?");
		Node C1aA = Node.createNode("MGMT113", true);
		Node C1aB = Node.createNode("HSPM297", true);
		Node C1bA = Node.createNode("MGMT613", true);
		Node C1bB = Node.createNode("MGMT513", true);
		Node C2aA = Node.createNode("MGMT213", true);
		Node C2aB = Node.createNode("HSPM397", true);
		Node C2bA = Node.createNode("MGMT623", true);
		Node C2bB = Node.createNode("MGMT523", true);

		// level5
		Node B2aA1 = Node.createNode("E-WOM", true);
		Node B2aA2 = Node.createNode("E-Booking", true);
		Node B2aB1 = Node.createNode("Ads", true);
		Node B2aB2 = Node.createNode("PR", true);
		Node B2bA1 = Node.createNode("ML");
		Node B2bA2 = Node.createNode("Eye-tracking", true);
		Node B2bB1 = Node.createNode("Pricing", true);
		Node B2bB2 = Node.createNode("Branding", true);

		// connect level0 and level1
		A.left = B;
		A.right = C;

		// connect level1 and level2
		B.left = B1;
		B.right = B2;
		C.left = C1;
		C.right = C2;

		// connect level2 and level3
		B1.left = B1a;
		B1.right = B1b;
		B2.left = B2a;
		B2.right = B2b;
		C1.left = C1a;
		C1.right = C1b;
		C2.left = C2a;
		C2.right = C2b;

		// connect level3 and level4
		B1a.left = B1aA;
		B1a.right = B1aB;
		B1b.left = B1bA;
		B1b.right = B1bB;
		B2a.left = B2aA;
		B2a.right = B2aB;
		B2b.left = B2bA;
		B2b.right = B2bB;
		C1a.left = C1aA;
		C1a.right = C1aB;
		C1b.left = C1bA;
		C1b.right = C1bB;
		C2a.left = C2aA;
		C2a.right = C2aB;
		C2b.left = C2bA;
		C2b.right = C2bB;

		// connect level4 and level5
		B2aA.left = B2aA1;
		B2aA.right = B2aA2;
		B2aB.left = B2aB1;
		B2aB.right = B2aB2;
		B2bA.left = B2bA1;
		B2bA.right = B2bA2;
		B2bB.left = B2bB1;
		B2bB.right = B2bB2;
	}
}
