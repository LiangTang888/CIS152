
/**model-view-controller is an architectural pattern idea to implement
 * user interfaces by dividing an application into three interconnected parts
 * Model manages data, logic, and rules of the application
 * view presents data to user
 * controller accepts input from the user and converts it to commands for the model or view
 * */
public class GUIApp {
	public static void main(String[] args) {
		Model m = new Model();//model, view, controllers are the three components aforementioned as MVC pattern
		View v = new View();
		Controller c = new Controller(m, v);
		c.init();
	}
}
