import javax.swing.JFrame;

/** main method */
public class View {//view is a component of MVC pattern of GUIApp class
	public ProfessorAssistFrame frame;
	public View () {
		frame = new ProfessorAssistFrame();//create a new frame
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);// click exit on the right top of the frame, the program is over
		frame.setVisible(true);//make the frame visible
	}
	
	public void update(Input input, Model model) {//method of update the info of the message to the user with the input and model
		frame.update(input, model);
	}
}
