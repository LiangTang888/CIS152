import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;


public class DecisionTreeTest {//Junit test for decision tree
	
	@Test
	void test() {
		DecisionTree d = new DecisionTree();
		assertEquals("Want to focus on research today?", d.root.Data); //test root.data
		assertEquals("Want to focus on grants?", d.root.left.Data);//test root.left.data
		assertEquals("Want to do grading?", d.root.right.Data); //test root.right.data
		assertEquals("Grants on federal sponsors?", d.root.left.left.Data);//test root.left.left.data
		assertEquals("Want to write journal papers?", d.root.left.right.Data);//test root.left.right.data
		assertNotEquals("Want to write journal papers", d.root.left.right.Data);//test root.left.right.data
	}
}
