

/**model is a component of MVC pattern mentioned in comments of GUIApp class*/
public class Model {
	public DecisionTree decisionTree;//decision tree, priority queue, stack are the three methods used in the app
	public LinkedListAndBubbleSort priorityQueue;
	public StackImplement stack;
	public Node currDecisionTreeNode;//this node is used in decision tree
	
	WorkMethod method = WorkMethod.DECISION_TREE; //this method is the default method
	
	public Model() {//constructor of Model()
		decisionTree = new DecisionTree();
		priorityQueue = new LinkedListAndBubbleSort();
		stack = new StackImplement();
		
		currDecisionTreeNode = decisionTree.root;
	}
	
	public void update(WorkMethod method, Input input) {//update the message in decision tree
		this.method = method; //method refers to method of this class
		
		if (method == WorkMethod.DECISION_TREE) {
			if (input.decision == Decision.YES) {//if the user clicks yes, go to left node
				currDecisionTreeNode = currDecisionTreeNode.left;
			} else if (input.decision == Decision.NO) {//if the user clicks no, go to right node
				currDecisionTreeNode = currDecisionTreeNode.right;
			}
		} else if (method == WorkMethod.PRIORITY_QUEUE || method == WorkMethod.STACK) {//if the method is priority queue or stack
			if (input.action == Action.ADD) {//when choosing add an element
				priorityQueue.insert(input.title, input.priority);//insert title and priority of the element into priority queue
				priorityQueue.bubbleSort();//conduct bubble sort in the priority queue
				stack.insert(input.title); //insert title of the element into the stack
			} else if (input.action == Action.REMOVE) {//remove the element 
				priorityQueue.delete(input.title); //delete the title of the removed element from priority queue
				stack.delete(input.title);//delete the title of the removed element from stack
			}
		}
	}
}
