
public enum Action {
	DISPLAY, ADD, REMOVE
}
