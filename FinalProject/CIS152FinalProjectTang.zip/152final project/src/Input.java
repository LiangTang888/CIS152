

public class Input {
	public Decision decision;//make choices in input for GUI
	public String title; //title in input for GUI
	public int priority;//priority in input for GUI
	public Action action; //after clicking ok, take an action 
}
